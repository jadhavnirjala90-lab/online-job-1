const API = "/api";
const getToken = () => localStorage.getItem("blogToken");
const saveSession = data => { localStorage.setItem("blogToken", data.token); localStorage.setItem("blogUser", JSON.stringify(data.user)); };
const logout = () => { localStorage.removeItem("blogToken"); localStorage.removeItem("blogUser"); location.href = "login.html"; };
async function request(path, options={}) {
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (getToken()) headers.Authorization = `Bearer ${getToken()}`;
  const response = await fetch(API + path, { ...options, headers });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) { if (response.status === 401 && getToken()) logout(); throw new Error(data.message || "Request failed."); }
  return data;
}
document.querySelectorAll("[data-logout]").forEach(el => el.addEventListener("click", logout));

const loginForm = document.getElementById("loginForm");
if (loginForm) loginForm.addEventListener("submit", async e => {
  e.preventDefault(); const message = document.getElementById("message");
  try { const f = new FormData(loginForm); const data = await request("/auth/login", { method:"POST", body:JSON.stringify({email:f.get("email"),password:f.get("password")}) }); saveSession(data); location.href="dashboard.html"; }
  catch(err) { message.textContent=err.message; }
});
const registerForm = document.getElementById("registerForm");
if (registerForm) registerForm.addEventListener("submit", async e => {
  e.preventDefault(); const message = document.getElementById("message");
  try { const f=new FormData(registerForm); const data=await request("/auth/register",{method:"POST",body:JSON.stringify({name:f.get("name"),email:f.get("email"),password:f.get("password")})}); saveSession(data); location.href="dashboard.html"; }
  catch(err) { message.textContent=err.message; }
});

async function requireUser() {
  if (!getToken()) { location.href="login.html"; throw new Error("Login required."); }
  return (await request("/auth/me")).user;
}
const blogList=document.getElementById("blogList");
if (blogList) (async()=>{ try {
  const user=await requireUser(); document.getElementById("welcomeName").textContent=user.name;
  const {blogs}=await request("/blogs");
  blogList.innerHTML=blogs.length ? "" : "<p class='muted'>You have not published a blog yet. Start your first story.</p>";
  blogs.forEach(blog=>{
    const card=document.createElement("article"); card.className="blog-card";
    const title=document.createElement("h2"); title.textContent=blog.title;
    const meta=document.createElement("div"); meta.className="blog-meta"; meta.textContent=new Date(blog.createdAt).toLocaleString();
    const content=document.createElement("p"); content.textContent=blog.content;
    const del=document.createElement("button"); del.className="delete"; del.textContent="Delete blog";
    del.addEventListener("click",async()=>{ if(!confirm("Delete this blog?"))return; try{await request("/blogs/"+blog._id,{method:"DELETE"});card.remove();}catch(err){document.getElementById("message").textContent=err.message;} });
    card.append(title,meta,content,del); blogList.append(card);
  });
 } catch(err) { const m=document.getElementById("message"); if(m)m.textContent=err.message; } })();

const blogForm=document.getElementById("blogForm");
if(blogForm) (async()=>{try{await requireUser();}catch(_){}})();
if(blogForm) blogForm.addEventListener("submit",async e=>{
  e.preventDefault();const message=document.getElementById("message");
  try{const f=new FormData(blogForm);await request("/blogs",{method:"POST",body:JSON.stringify({title:f.get("title"),content:f.get("content")})});location.href="dashboard.html";}
  catch(err){message.textContent=err.message;}
});

if(document.getElementById("profileName")) (async()=>{try{
  const user=await requireUser();document.getElementById("profileName").textContent=user.name;
  document.getElementById("profileEmail").textContent=user.email;
  document.getElementById("avatar").textContent=user.name.charAt(0).toUpperCase();
  document.getElementById("joined").textContent="Member since "+new Date(user.createdAt).toLocaleDateString();
}catch(err){const el=document.getElementById("profileName");if(el)el.textContent=err.message;}})();
