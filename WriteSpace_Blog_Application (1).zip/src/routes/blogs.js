const router = require("express").Router();
const Blog = require("../models/Blog");
const auth = require("../middleware/auth");

router.use(auth); // All blog routes below require a valid JWT.

router.get("/", async (req, res, next) => {
  try {
    // Important: filter by authenticated user's ID, never by a client-supplied author.
    const blogs = await Blog.find({ author: req.userId }).sort({ createdAt: -1 });
    res.json({ blogs });
  } catch (err) { next(err); }
});

router.post("/", async (req, res, next) => {
  try {
    const title = String(req.body.title || "").trim();
    const content = String(req.body.content || "").trim();
    if (!title || title.length > 120 || !content || content.length > 10000)
      return res.status(400).json({ message: "Title and content are required (title max 120, content max 10,000 characters)." });
    const blog = await Blog.create({ title, content, author: req.userId });
    res.status(201).json({ blog });
  } catch (err) { next(err); }
});

router.delete("/:id", async (req, res, next) => {
  try {
    // Ownership check prevents deleting another user's blog.
    const deleted = await Blog.findOneAndDelete({ _id: req.params.id, author: req.userId });
    if (!deleted) return res.status(404).json({ message: "Blog not found." });
    res.json({ message: "Blog deleted." });
  } catch (err) { next(err); }
});
module.exports = router;
