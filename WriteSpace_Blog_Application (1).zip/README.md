# WriteSpace — Secure Blog Application

A responsive blog app built with HTML, CSS, JavaScript, Node.js, Express, MongoDB and JWT.

## Features
- Register and log in with hashed passwords (bcrypt).
- JWT authentication for protected API endpoints.
- Private dashboard: `/api/blogs` always filters by the authenticated user's ID.
- Create and delete your own blog posts only.
- User profile and logout.
- Basic security headers, request-size limit and API rate limiting.

## Requirements
- Node.js 18+
- MongoDB local installation or a MongoDB Atlas database

## Run locally
1. Extract the ZIP and open the project folder in VS Code.
2. Open a terminal in that folder and run `npm install`.
3. Copy `.env.example` to `.env`.
4. Put your MongoDB connection string in `MONGODB_URI`.
5. Replace `JWT_SECRET` with a long, random secret (never publish `.env`).
6. Run `npm run dev` (or `npm start`).
7. Open `http://localhost:3000`.

## Test
1. Register with an email and password of at least 8 characters.
2. Create a blog from **Write a blog**.
3. Log out and register a second user.
4. Confirm the second user's dashboard does not show the first user's blog.

## Main API routes
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me` (JWT required)
- `GET /api/blogs` (JWT required; current user's posts only)
- `POST /api/blogs` (JWT required)
- `DELETE /api/blogs/:id` (JWT required; owner only)

## Security note
This is an educational starter project. The frontend stores the JWT in `localStorage` for easy demonstration. For a production deployment, prefer secure, HttpOnly, SameSite cookies with CSRF protection, HTTPS, stronger validation, logging and secret management. Never commit `.env` or real credentials.

## GitHub upload
Create a new **public** or **private** repository on GitHub. Upload the extracted project files, excluding `node_modules` and `.env`. Add this README as the project description.

## LinkedIn
Create a post describing the project and attach screenshots or the GitHub repository URL. Do not upload passwords, database credentials or `.env` files.
